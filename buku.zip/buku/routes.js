const {
  getBookHandler,
  findBookHandler,
  findBookByIdHandler,
  editBookFromIdHandler,
  deleteBookFromIdHandler,
} = require('./handler');

const routes = [
  {
    method: 'POST',
    path: '/books',
    handler: getBookHandler,
  },
  {
    method: 'GET',
    path: '/books',
    handler: findBookHandler,
  },
  {
    method: 'GET',
    path: '/books/{id}',
    handler: findBookByIdHandler,
  },
  {
    method: 'PUT',
    path: '/books/{id}',
    handler: editBookFromIdHandler,
  },
  {
    method: 'DELETE',
    path: '/books/{id}',
    handler: deleteBookFromIdHandler,
  },
];

module.exports = routes;
