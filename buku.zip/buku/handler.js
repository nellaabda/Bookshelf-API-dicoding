const { nanoid } = require('nanoid');
const books = require('./books');

// menyimpan buku
const getBookHandler = (request, h) => {
  const {
    name, author, summary, pageCount, readPage, year, publisher,
  } = request.payload;

  if (name === undefined) {
    const response = h.response({
      status: 'fail',
      message: 'Gagal menambahkan buku. Mohon isi nama buku',
    });
    response.code(400);
    return response;
  }
  if (readPage > pageCount) {
    const response = h.response({
      status: 'fail',
      message: 'Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount',
    });
    response.code(400);
    return response;
  }
  const id = nanoid(16);
  const insertedAt = new Date().toISOString();
  const updateAt = insertedAt;
  let reading;
  if (readPage<pageCount){
    reading = true;
  }else if(pageCount>readPage){
    reading = false;
  };

  const finished = (readPage === pageCount);

  const dataBuku = {
    id, name, year, author, summary, publisher, insertedAt, updateAt, finished, pageCount, readPage, reading,
  };
  books.push(dataBuku);

 
  const success = books.filter((book) => book.id === id).length > 0;

  if (success) {
    const response = h.response({
      status: 'success',
      message: 'Buku berhasil ditambahkan',
      data: {
        bookId: id,
      },

    });
    response.code(201);
    return response;
  }
  
  const response = h.response({
    status: 'eror',
    message: 'Buku gagal ditambahkan',
  });
  response.code(500);
  return response;
};

// menampilkan data buku
const findBookHandler = (request, h) => {
  
  const {name}=request.query;
  const {id} = request.query;
  const book = books.filter((x)=>x.id === id)[0];
  
  if (!name&&book!==-1) {
    const response = h.response({
      status: 'success',
      message: 'Buku berhasil ditambahkan',
      data : {
        books :books.map((book) => ({
          id: book.id,
          name: book.name,
          publisher: book.publisher})),
      },
    });
    response.code(200);
    return response;
  }
  
  const response = h.response({
    status: 'fail',
    message: 'Buku tidak ditambahkan',
  });
  response.code(404);
  return response;
};

// mencari buku dengan id
const findBookByIdHandler = (request, h) => {
  const {id} = request.params;
  const book = books.filter((x)=>x.id === id)[0];
  

  if (book !== undefined) {
    book['updatedAt'] = (new Date()).toISOString()
    book['reading'] = false
    const response = h.response({
      status: 'success',
      data : {
        book,
      },
    })

    response.code(200)
    return response
  }
  
  const response = h.response({
    status: 'fail',
    message: 'Buku tidak ditemukan',
  });

  response.code(404)
  return response
};

// mengubah data buku
const editBookFromIdHandler = (request, h) => {
  const { id } = request.params;
  const {
    name, 
    author, 
    summary, 
    pageCount, 
    readPage,
    year, 
    publisher, 
    reading,
  } = request.payload;

  if (readPage > pageCount) {
    const response = h.response({
      status: 'fail',
      message: 'Gagal memperbarui buku. readPage tidak boleh lebih besar dari pageCount',
    });
    response.code(400);
    return response;
  };
  

  if (name === undefined) {
    const response = h.response({
      status: 'fail',
      message: 'Gagal memperbarui buku. Mohon isi nama buku',
    });
    response.code(400);
    return response;
  };
  
  const updateAt = new Date().toISOString();
  const indexBuku = books.findIndex((book) => book.id === id);

  if (indexBuku !== -1) {
    books[indexBuku] = {
      ...books[indexBuku],
      name, 
      year, 
      author, 
      summary, 
      publisher, 
      updateAt, 
      pageCount, 
      readPage, 
      reading,
      updateAt,
    };
    console.log(indexBuku);
    const response = h.response({
      status: 'success',
      message: 'Buku berhasil diperbarui',
    });
    response.code(200);
    return response;
  }

  const response = h.response({
    status: 'fail',
    message: 'Gagal memperbarui buku. Id tidak ditemukan',
  });
  response.code(404);
  return response;
};

// menghapus buku
const deleteBookFromIdHandler = (request, h) => {
  const { id } = request.params;
  const indexBuku = books.findIndex((book) => book.id === id);
  
  console.log (indexBuku);
  if (indexBuku !== -1) {
    books.splice(indexBuku, 1);
    const response = h.response({
      status: 'success',
      message: 'Buku berhasil dihapus',
    });
    response.code(200);
    return response;
  };

  const response = h.response({
    status: 'fail',
    message: 'Buku gagal dihapus. Id tidak ditemukan',
  });
  response.code(404);
  return response;
 
};

// export module
module.exports = {
  getBookHandler,
  findBookHandler,
  findBookByIdHandler,
  editBookFromIdHandler,
  deleteBookFromIdHandler,
};
